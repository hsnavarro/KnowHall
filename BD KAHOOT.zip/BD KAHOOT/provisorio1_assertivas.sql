-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: provisorio1
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assertivas`
--

DROP TABLE IF EXISTS `assertivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assertivas` (
  `assID` int(11) NOT NULL AUTO_INCREMENT,
  `assertiv` varchar(200) DEFAULT NULL,
  `peso` varchar(200) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `questao_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`assID`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assertivas`
--

LOCK TABLES `assertivas` WRITE;
/*!40000 ALTER TABLE `assertivas` DISABLE KEYS */;
INSERT INTO `assertivas` VALUES (1,'1','1',1,1),(2,'1','1',1,1),(3,'2','2',1,1),(4,'3','3',1,1),(5,'1','1',2,2),(6,'2','2',2,2),(7,'1','2',2,3),(8,'3','3',2,3),(9,'4','44',2,3),(10,'1','1',3,4),(11,'R','1',3,5),(12,'1','1',3,5),(13,'3','3',3,5),(14,'2','2',4,6),(15,'2','3',4,6),(16,'1','1',5,7),(17,'1','2',6,8),(18,'4','3',6,9),(19,'2','5',6,9),(20,'1','1',8,10),(21,'2','2',10,11),(22,'3','2',11,12),(23,'1','2',11,13),(24,'2','3',11,13),(25,'17','1',12,14),(26,'18','2',12,14),(27,'24','3',12,14),(28,'10','1',12,15),(29,'20','2',12,15),(30,'30','3',12,15),(31,'40','4',12,15),(32,'10','1',12,16),(33,'20','2',12,16),(34,'30','3',12,16),(35,'1','1',13,17),(36,'2','2',13,17),(37,'2','2',13,18),(38,'2','2',13,18),(39,'33','3',13,19),(40,'1','1',14,20),(41,'2','2',14,20),(42,'1','1',14,21),(43,'1','1',15,22),(44,'1','1',16,23),(45,'124','4',16,24),(46,'12','12',16,24),(47,'1','1',17,25),(48,'1','1',17,25),(49,'Manter as características do objeto.','1',18,26),(50,'Mudar ou transformar algo existente de modo que se torne algo novo.','2',18,26),(51,'Mudar o objeto para o pior.','3',18,26),(52,'Criar algo novo.','4',18,26),(53,'Pensamento estratégico do design focado no ser humano.','1',18,27),(54,'Pensamento estratégico do design focado no produto.','2',18,27),(55,'Pensamento estratégico focado no lucro.  ','3',18,27),(56,'Pensamento estratégico que não está relacionado com inovação.','4',18,27),(57,'Modelo Diamante Duplo','1',18,28),(58,'Modelo de Stanford (d.school)','2',18,28),(59,'Modelo dos 3I´s','3',18,28),(60,'Modelo de Sturm-Liouville','4',18,28),(61,'Personas','1',18,29),(62,'Jornada do usuário','2',18,29),(63,'Gamificação','3',18,29),(64,'Diagrama de afinidades','4',18,29),(65,'Brainstorming','1',18,30),(66,'Precificação','2',18,30),(67,'Mapa de empatia','3',18,30),(68,'Storyboard','4',18,30),(69,'12','1',19,31),(70,'2','3',19,31),(71,'1','1',20,32),(72,'1','1',22,34);
/*!40000 ALTER TABLE `assertivas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-18 11:10:38
