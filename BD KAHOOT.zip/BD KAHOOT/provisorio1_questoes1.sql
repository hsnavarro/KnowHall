-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: provisorio1
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `questoes1`
--

DROP TABLE IF EXISTS `questoes1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questoes1` (
  `questaoID` int(11) NOT NULL AUTO_INCREMENT,
  `pergunta` varchar(200) DEFAULT NULL,
  `assert` varchar(100) DEFAULT NULL,
  `materia` varchar(200) DEFAULT NULL,
  `submateria` varchar(200) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `minuto` int(11) DEFAULT NULL,
  `segundo` int(11) DEFAULT NULL,
  `dificuldade` varchar(100) DEFAULT NULL,
  `r` varchar(100) DEFAULT NULL,
  `qc` int(11) DEFAULT NULL,
  `qf` int(11) DEFAULT NULL,
  PRIMARY KEY (`questaoID`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questoes1`
--

LOCK TABLES `questoes1` WRITE;
/*!40000 ALTER TABLE `questoes1` DISABLE KEYS */;
INSERT INTO `questoes1` VALUES (1,'Ricrack1','4','Selecionar Outro','Selecionar Outro',1,4,4,'Medio',NULL,NULL,1),(2,'42','2','Matematica','Selecionar Outro',2,3,0,'Medio','4',NULL,NULL),(3,'4','3','Selecionar Outro','Selecionar Outro',2,4,3,'Medio','4',NULL,NULL),(4,'Ricrack','1','Quimica','Inorganica',3,0,0,'Medio','1',NULL,NULL),(5,'3','3','Fisica','Dinâmica',3,0,0,'Facil','3',NULL,NULL),(6,'214','2','Quimica','Mecanismos',4,3,0,'Facil','4',NULL,NULL),(7,'1','1','Matematica','Algebra Linear',5,0,0,'Facil','2',NULL,NULL),(8,'1','1','Fisica','Gravitação',6,0,0,'Facil','2',NULL,NULL),(9,'4','2','Quimica','Inorganica',6,0,0,'Facil','6',NULL,NULL),(10,'1','1','Matematica','Algebra Linear',8,0,0,'Facil','1',NULL,NULL),(11,'1','1','Matematica','Algebra Linear',10,0,0,'Medio','2',NULL,NULL),(12,'2','1','Quimica','Inorganica',11,0,0,'Facil','2',NULL,NULL),(13,'2','2','Fisica','Gravitação',11,0,0,'Facil','1',NULL,NULL),(14,'Quantos anos tem o adinê?','3','Fisica','Gravitação',12,3,4,'Medio','3',2,4),(15,'Quantos anos o Ricrack tem?','4','Fisica','Gravitação',12,3,4,'Dificil','2',1,4),(16,'Quantos anos o Bozza tem?','3','Matematica','Algebra Linear',12,4,0,'Medio','3',2,4),(17,'1','2','Quimica','Inorganica',13,0,0,'Facil','1',NULL,NULL),(18,'2','2','Quimica','Inorganica',13,0,0,'Facil','2',NULL,NULL),(19,'3','1','Biologia','Genética',13,0,0,'Facil','3',NULL,NULL),(20,'Quanto é 1+1?','2','Português','Gramática',14,0,0,'Medio','2',NULL,NULL),(21,'1231','1','Fisica','Gravitação',14,0,0,'Facil','1',NULL,NULL),(22,'2','1','Quimica','Inorganica',15,0,0,'Facil','1',NULL,NULL),(23,'1','1','Fisica','Gravitação',16,0,0,'Facil','1',1,1),(24,'4','2','Fisica','Gravitação',16,0,0,'Facil','23',0,1),(25,'1','2','Matematica','Algebra Linear',17,0,0,'Facil','12',0,0),(26,'O que é inovação ?','4','Desenvolvimento de Projetos','Design Thinking',18,0,0,'Facil','2',1,4),(27,'O que é Design Thinking ?','4','Desenvolvimento de Projetos','Design Thinking',18,0,0,'Medio','1',1,4),(28,'Quais dessas modelagens não representa o processo de Design Thinking ?','4','Desenvolvimento de Projetos','Design Thinking',18,0,0,'Medio','4',1,4),(29,'DIga qual a soma das assertivas que contém ferramentas de inspiração no Design Thinking .','4','Desenvolvimento de Projetos','Design Thinking',18,0,0,'Dificil','7',1,3),(30,'Diga qual a soma das assertivas que contém ferramentas de idealização no Design Thinking .','4','Desenvolvimento de Projetos','Design Thinking',18,0,0,'Dificil','5',0,3),(31,'1','2','Biologia','Genética',19,0,0,'Medio','1',7,16),(32,'1','1','Fisica','Gravitação',20,0,0,'Dificil','1',11,28),(33,'1','1','Matematica','Algebra Linear',21,0,30,'Facil',NULL,0,0),(34,'1','1','Fisica','Gravitação',22,0,30,'Facil','1',0,8);
/*!40000 ALTER TABLE `questoes1` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-18 11:10:35
